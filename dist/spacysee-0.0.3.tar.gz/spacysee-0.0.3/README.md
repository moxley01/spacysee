# SpacySee

A project the helps you visualize your Spacy docs in Jupyter notebooks
